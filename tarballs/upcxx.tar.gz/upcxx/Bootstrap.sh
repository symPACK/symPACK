## Create the configure script and setup files with autoconf and automake

set -x

autoreconf -fi
